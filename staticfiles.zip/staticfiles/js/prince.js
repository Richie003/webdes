//console
let name = 'Richie '
console.log(name);