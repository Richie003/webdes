def values(x, y):
	multiply= x * y
	return multiply


value1= 15
value2= 5
solution= values(value1, value2)
print(f'your answer is {solution}')
