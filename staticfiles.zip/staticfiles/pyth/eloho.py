# string= 'hello'
# intrger= 1
# floats= 1.5
# boolean= True or False
					#variables
name = input('your name: ')
print(name + 'welcome to my world')