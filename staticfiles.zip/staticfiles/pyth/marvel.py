import sqlite3 as sl
import html

con= sl.connect('marvel.db')
# with con: 	
	# con.execute("""CREATE TABLE GOODS (
	# id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, name TEXT, price INTEGER, stock DECIMAL, legit BOOLEAN);
	# """)
sql = 'INSERT INTO GOODS (id, name, price, stock, legit) values(?, ?, ?, ?, ?)'
data = [
(1, 'Bag', 1000, 34.0, True), 
(2, 'Wrapper', 2200, 27.32, True), 
(3, 'Lamboughini', 220000000, 29.5, True),
(4, 'Hp_Laptop', 115000, 67.9, True)
]
with con:
	con.executemany(sql, data)